#!/bin/bash

# Check if the required arguments are provided
if [ "$#" -ne 2 ]; then
  echo "Usage: $0 <username> <password>"
  exit 1
fi

# Get the username and password from the command-line arguments
USERNAME=$1
PASSWORD=$2

# Define the API endpoint
API_URL="https://etelvpn.com/api/apiauth.php"

# Make the API request and capture the response
response=$(curl -s -X POST -d "username=$USERNAME&password=$PASSWORD" "$API_URL")

# Check if the response is 1 or 0
if [ "$response" -eq "1" ]; then 
    echo "$USERNAME | $PASSWORD is invalid"
    echo "REJECT"
else
    echo "ACCEPT"
fi